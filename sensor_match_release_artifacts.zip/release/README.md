# Sensor-Match Study — released artifacts

Companion data for "Sensor Match Dominates Pretraining Source in Geospatial Foundation Model Transfer".
Code and notebook: https://github.com/horozbabasi/Sensor-Match-Study-

## Contents
- `results/eurosat_results.csv`, `results/resisc45_results.csv` — one row per run (510 main + 37 augmentation-tier runs): all six metrics at both stages, epochs/steps actually run, floor flags, split hashes, GPU, timing.
- `results/seed_tests.csv` — 396 seed-level comparisons (Wilcoxon, paired t, Holm within budget).
- `results/mcnemar_pvalues.csv` — McNemar + Jaccard for all 66 pairs at every budget, seed 42 (Tables VIII(a)/(b), IX).
- `results/per_class_f1.csv` — per-class F1 for every run and stage (Tables XI, XII, Fig. 8).
- `results/factorial_eurosat.csv`, `label_efficiency.csv`, `synthesis_deltas.csv`, `frozen_vs_finetuned.csv` — derived analyses of Section 3.9.
- `results/min_steps_sweep.csv` — the pilot sweep that fixed the 300/200 optimiser-step floor.
- `results/dataset_summary.*` — per-class split counts.
- `splits/` — the fixed RESISC45 70/15/15 split (seed 42). EuroSAT uses the dataset's released split CSVs (hashes on every result row).
- `derived/` — the aggregated tables used to typeset the manuscript (means/std over seeds, Stage 1 vs 2, McNemar and Jaccard at full labels, EuroSAT per-class F1).
- `confusion/` — confusion matrices for the two configurations discussed in Section 5.8 (seed 42, full labels, Stage 2).
- `environment.txt` — the software environment printed by the notebook at execution.

## Not in this archive (too large for GitHub)
- `preds/` — per-image predictions and probabilities for all 510 runs (compressed .npz, one per run and stage)
- `checkpoints/` — full-label seed-42 checkpoints
- `logs/curves_*.png` — per-run training curves
These live in the `fm_transfer_study` Drive folder; deposit them on Zenodo (or share the folder publicly) and cite the DOI/link in Section 8.
